#!/usr/bin/env python3
"""
Tesseract OCR configuration
Generated automatically by tesseract_setup.py
"""

# Path to Tesseract executable
TESSERACT_PATH = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
